

function musOverSF(element) {
	document.getElementById("melding").style.color="black";
	if (element == document.getElementById('find')){
		document.getElementById("melding").innerHTML="<div class='alert alert-warning'>Tast inn søkeord.</div>";
	}}