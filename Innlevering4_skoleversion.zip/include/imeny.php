<nav class="col-md-3 sidenav">
<h5><strong>Brukerfunksjoner</strong></h5>
<ul class="nav nav-pills nav-stacked">
	<li><a href="./">Hjem</a></li>
	<li><a href="./registrere-klasse.php">Registrere ny klasse</a></li>
	<li><a href="./registrere-student.php">Registrere ny student</a><ul></ul></li>
	<li><a href="./last-opp-bilde.php">Last opp bilde</a></li>
	<li><a href="./vis-data-registrert.php">Vis registrert data</a></li>
	<li><a href="./endre-data.php">Endre registrert data</a></li>
	<li><a href="./slett-data.php">Slett registrert data</a></li>
	<li><a href="./find.php">S&oslash;k</a></li>
	<li><a href="./utlogging.php">Logg ut</a></li>
</ul>
</nav>