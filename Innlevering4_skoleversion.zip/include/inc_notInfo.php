<div id="ikkeinnloggetinfo"><div class="alert alert-warning">
    <div>For å benytte denne applikasjonen må du være innlogget. Klikk <a href="./registrerskjema.php">her</a> for å registrere deg.</div>
  </div></div>