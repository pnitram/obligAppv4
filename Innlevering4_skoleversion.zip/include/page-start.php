<div class="page-header">

	<div class="container">
<?php 

		session_start();
	 	@$innloggetBruker=$_SESSION["tuxbrukernavn"]; 

?>
	

	<img style="height: 80px;" src="./img/tux.png" class="pull-right" alt="Tux Penguine">

            <h3>Obligatorisk oppgave 4</h3>

            <h4><small>Student: Martin Pedersen og Unni Le</small></h4>

            </div>

        </div>