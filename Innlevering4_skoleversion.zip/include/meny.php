


<?php

if (!$innloggetBruker) {
	include("./include/umeny.php");
}

else {
	include ("./include/imeny.php");
} 

?>





