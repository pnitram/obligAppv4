	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/newstyle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <!-- DATEPICKER CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="./css/fileinput.min.css">
    <!-- LASTE INN SCRIPTS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!-- DATEPICKER -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.12.0/moment-with-locales.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
    <!-- FILEINPUT -->
    <script src="./js/canvas-to-blob.min.js"></script>
    <script src="./js/fileinput.min.js"></script>
    <script src="./js/fileinput_locale_nb.js"></script>

    <!-- VALIDERING OG HENDELSER -->
    <script src="./js/hendelser.js"></script>
    <script src="./js/validering.js"></script>
    <script src="./js/jqevent.js"></script>
    <script src="./js/clearForm.js"></script>
    <script src="./js/soekhendelse.js"></script>